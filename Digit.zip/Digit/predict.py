"""
predict.py
==========
Standalone prediction helper.

Loads the trained CNN model and exposes two functions:
  • predict_single(img_array)  → single-digit prediction
  • predict_multi(img_array)   → multi-digit prediction via contour segmentation

Both functions accept a NumPy array (H × W, uint8, 0–255 grayscale).
"""

import cv2
import numpy as np
from tensorflow import keras


# ─────────────────────────────────────────────
# 1. LOAD MODEL (once, at import time)
# ─────────────────────────────────────────────

MODEL_PATH = "model/digit_model.h5"

try:
    model = keras.models.load_model(MODEL_PATH)
    print(f"[INFO] Model loaded from {MODEL_PATH}")
except Exception as e:
    print(f"[WARN] Could not load model: {e}")
    model = None


# ─────────────────────────────────────────────
# 2. IMAGE PREPROCESSING HELPERS
# ─────────────────────────────────────────────

def preprocess_digit(roi: np.ndarray) -> np.ndarray:
    """
    Prepare a single-digit ROI (region-of-interest) for the CNN.

    Steps:
      1. Resize to 28 × 28
      2. Normalize pixels to [0, 1]
      3. Reshape to (1, 28, 28, 1)
    """
    resized = cv2.resize(roi, (28, 28), interpolation=cv2.INTER_AREA)
    normalized = resized.astype("float32") / 255.0
    return normalized.reshape(1, 28, 28, 1)


# ─────────────────────────────────────────────
# 3. SINGLE-DIGIT PREDICTION
# ─────────────────────────────────────────────

def predict_single(img_array: np.ndarray) -> dict:
    """
    Predict a single digit from a grayscale image array.

    Parameters
    ----------
    img_array : np.ndarray
        Grayscale image (any size, uint8, 0-255).

    Returns
    -------
    dict : {"digit": int, "confidence": float}
    """
    if model is None:
        return {"digit": -1, "confidence": 0.0, "error": "Model not loaded"}

    processed = preprocess_digit(img_array)
    predictions = model.predict(processed, verbose=0)  # shape: (1, 10)
    digit = int(np.argmax(predictions[0]))
    confidence = float(np.max(predictions[0])) * 100

    return {"digit": digit, "confidence": round(confidence, 2)}


# ─────────────────────────────────────────────
# 4. MULTI-DIGIT PREDICTION
# ─────────────────────────────────────────────

def segment_digits(gray: np.ndarray) -> list:
    """
    Detect individual digit regions using contour analysis.

    Returns a list of (x, y, w, h) bounding boxes sorted left → right.
    """
    # Threshold: white digits on black background (MNIST style)
    _, thresh = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)

    # Morphological dilation helps connect broken strokes
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    dilated = cv2.dilate(thresh, kernel, iterations=1)

    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)

    bboxes = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        # Ignore very small noise contours
        if w > 10 and h > 10:
            bboxes.append((x, y, w, h))

    # Sort left to right by x-coordinate
    bboxes.sort(key=lambda b: b[0])
    return bboxes


def predict_multi(img_array: np.ndarray) -> dict:
    """
    Predict multiple digits from a grayscale image.

    Segments each digit via contours, predicts individually,
    and concatenates the results.

    Parameters
    ----------
    img_array : np.ndarray
        Grayscale image (any size, uint8, 0-255).

    Returns
    -------
    dict : {"prediction": str, "digits": list[dict]}
    """
    if model is None:
        return {"prediction": "", "digits": [], "error": "Model not loaded"}

    bboxes = segment_digits(img_array)

    if not bboxes:
        # Fall back to whole-image single-digit prediction
        result = predict_single(img_array)
        return {
            "prediction": str(result["digit"]),
            "digits": [result],
        }

    results = []
    for (x, y, w, h) in bboxes:
        # Add padding around the bounding box
        pad = 8
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(img_array.shape[1], x + w + pad)
        y2 = min(img_array.shape[0], y + h + pad)

        roi = img_array[y1:y2, x1:x2]
        result = predict_single(roi)
        results.append(result)

    prediction_str = "".join(str(r["digit"]) for r in results)
    avg_conf = round(float(np.mean([r["confidence"] for r in results])), 2)

    return {
        "prediction": prediction_str,
        "digits": results,
        "average_confidence": avg_conf,
    }


# ─────────────────────────────────────────────
# QUICK CLI TEST
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python predict.py <image_path>")
        sys.exit(1)

    path = sys.argv[1]
    img  = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"[ERROR] Could not read image: {path}")
        sys.exit(1)

    result = predict_multi(img)
    print(f"\nPrediction : {result['prediction']}")
    for i, d in enumerate(result["digits"]):
        print(f"  Digit {i+1}: {d['digit']}  (confidence: {d['confidence']}%)")
