"""
app.py
======
Flask web application for the MNIST Multi-Digit Handwritten Recognition System.

Routes:
  GET  /          → Serve the drawing canvas (index.html)
  POST /predict   → Accept Base64 canvas image, return digit prediction as JSON
"""

import base64
import io
import numpy as np
import cv2
from flask import Flask, render_template, request, jsonify
from PIL import Image
from tensorflow import keras

from predict import predict_multi   # our prediction helper


# ─────────────────────────────────────────────
# FLASK APP SETUP
# ─────────────────────────────────────────────

app = Flask(__name__)

# Load the trained model once at startup
MODEL_PATH = "model/digit_model.h5"
try:
    model = keras.models.load_model(MODEL_PATH)
    print(f"[INFO] Loaded model from {MODEL_PATH}")
except Exception as e:
    model = None
    print(f"[WARN] Model not loaded – train first with train_model.py\n       Error: {e}")


# ─────────────────────────────────────────────
# ROUTE: HOME
# ─────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the main drawing canvas page."""
    return render_template("index.html")


# ─────────────────────────────────────────────
# ROUTE: PREDICT
# ─────────────────────────────────────────────

@app.route("/predict", methods=["POST"])
def predict():
    """
    Receive a Base64-encoded canvas PNG, preprocess it,
    run multi-digit prediction, and return JSON results.

    Expected JSON body:
        { "image": "data:image/png;base64,<data>" }

    Response JSON:
        {
          "prediction": "583",
          "digits": [
            {"digit": 5, "confidence": 97.3},
            {"digit": 8, "confidence": 95.1},
            {"digit": 3, "confidence": 98.7}
          ],
          "average_confidence": 97.0
        }
    """
    if model is None:
        return jsonify({"error": "Model not loaded. Run train_model.py first."}), 500

    data = request.get_json()
    if not data or "image" not in data:
        return jsonify({"error": "No image data received."}), 400

    try:
        # ── 1. Decode Base64 image ──────────────────────────────────────────
        image_data = data["image"]
        # Strip the data-URL prefix: "data:image/png;base64,<actual_data>"
        if "," in image_data:
            image_data = image_data.split(",")[1]

        raw_bytes = base64.b64decode(image_data)

        # ── 2. Open with Pillow & convert to grayscale ──────────────────────
        pil_img = Image.open(io.BytesIO(raw_bytes)).convert("L")

        # ── 3. Convert to NumPy array ────────────────────────────────────────
        img_array = np.array(pil_img, dtype=np.uint8)

        # ── 4. Invert colors so digits are WHITE on BLACK (MNIST style) ──────
        #       Canvas: black digits on white background
        #       MNIST:  white digits on black background
        img_array = cv2.bitwise_not(img_array)

        # ── 5. Predict (handles single & multi-digit via contour segmentation) ─
        result = predict_multi(img_array)

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🚀  MNIST Digit Recognition Server")
    print("    Open your browser at http://127.0.0.1:5000\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
