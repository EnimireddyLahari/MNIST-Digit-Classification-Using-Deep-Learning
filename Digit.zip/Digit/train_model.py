"""
train_model.py
==============
Trains a Convolutional Neural Network (CNN) on the MNIST dataset
and saves the trained model to disk.

Usage:
    python train_model.py
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers


# ─────────────────────────────────────────────
# 1. LOAD & PREPROCESS DATA
# ─────────────────────────────────────────────

def load_and_preprocess():
    """Load MNIST dataset and prepare it for CNN training."""
    print("[INFO] Loading MNIST dataset...")
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

    # Normalize pixel values from [0, 255] → [0.0, 1.0]
    x_train = x_train.astype("float32") / 255.0
    x_test  = x_test.astype("float32")  / 255.0

    # Reshape: (samples, 28, 28) → (samples, 28, 28, 1)  — CNN expects a channel dim
    x_train = x_train.reshape(-1, 28, 28, 1)
    x_test  = x_test.reshape(-1, 28, 28, 1)

    print(f"[INFO] Training samples : {x_train.shape[0]}")
    print(f"[INFO] Testing  samples : {x_test.shape[0]}")
    return (x_train, y_train), (x_test, y_test)


# ─────────────────────────────────────────────
# 2. BUILD THE CNN MODEL
# ─────────────────────────────────────────────

def build_model():
    """
    CNN Architecture
    ────────────────
    Input  → Conv2D(32) → MaxPool → Conv2D(64) → MaxPool
           → Flatten → Dense(128) → Output(10, Softmax)
    """
    model = keras.Sequential([
        # --- Block 1 ---
        layers.Conv2D(32, kernel_size=(3, 3), activation="relu",
                      input_shape=(28, 28, 1), name="conv1"),
        layers.MaxPooling2D(pool_size=(2, 2), name="pool1"),

        # --- Block 2 ---
        layers.Conv2D(64, kernel_size=(3, 3), activation="relu", name="conv2"),
        layers.MaxPooling2D(pool_size=(2, 2), name="pool2"),

        # --- Classifier ---
        layers.Flatten(name="flatten"),
        layers.Dense(128, activation="relu", name="dense1"),
        layers.Dropout(0.3, name="dropout"),          # regularisation
        layers.Dense(10, activation="softmax", name="output"),
    ], name="MNIST_CNN")

    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    model.summary()
    return model


# ─────────────────────────────────────────────
# 3. TRAIN
# ─────────────────────────────────────────────

def train(model, x_train, y_train, x_test, y_test, epochs=5):
    """Train the model and return the history object."""
    print(f"\n[INFO] Training for {epochs} epoch(s)…")
    history = model.fit(
        x_train, y_train,
        epochs=epochs,
        batch_size=128,
        validation_data=(x_test, y_test),
    )
    return history


# ─────────────────────────────────────────────
# 4. EVALUATE
# ─────────────────────────────────────────────

def evaluate(model, x_test, y_test):
    """Print final test accuracy."""
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\n[RESULT] Test Accuracy : {acc * 100:.2f}%")
    print(f"[RESULT] Test Loss     : {loss:.4f}")


# ─────────────────────────────────────────────
# 5. SAVE MODEL
# ─────────────────────────────────────────────

def save_model(model, path="model/digit_model.h5"):
    """Save the trained model to disk."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    model.save(path)
    print(f"\n[INFO] Model saved → {path}")


# ─────────────────────────────────────────────
# 6. VISUALISE TRAINING CURVES
# ─────────────────────────────────────────────

def plot_history(history):
    """Save training accuracy & loss curves as a PNG."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    fig.suptitle("MNIST CNN – Training Curves", fontsize=14, fontweight="bold")

    # Accuracy
    ax1.plot(history.history["accuracy"],     label="Train Accuracy")
    ax1.plot(history.history["val_accuracy"], label="Val  Accuracy")
    ax1.set_title("Accuracy")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy")
    ax1.legend()
    ax1.grid(True)

    # Loss
    ax2.plot(history.history["loss"],     label="Train Loss")
    ax2.plot(history.history["val_loss"], label="Val  Loss")
    ax2.set_title("Loss")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Loss")
    ax2.legend()
    ax2.grid(True)

    plt.tight_layout()
    plt.savefig("training_curves.png", dpi=150)
    print("[INFO] Training curves saved → training_curves.png")
    plt.show()


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    (x_train, y_train), (x_test, y_test) = load_and_preprocess()
    model   = build_model()
    history = train(model, x_train, y_train, x_test, y_test, epochs=5)
    evaluate(model, x_test, y_test)
    save_model(model)
    plot_history(history)
