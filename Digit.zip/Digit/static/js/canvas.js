/**
 * canvas.js
 * =========
 * Handles all canvas drawing interactions and communicates
 * with the Flask backend to get digit predictions.
 */

(function () {
  "use strict";

  // ── DOM references ──────────────────────────────────────────────────────
  const canvas      = document.getElementById("drawing-canvas");
  const ctx         = canvas.getContext("2d");
  const predictBtn  = document.getElementById("btn-predict");
  const clearBtn    = document.getElementById("btn-clear");
  const resultBox   = document.getElementById("result-display");
  const loader      = document.getElementById("loader");

  // ── Drawing state ────────────────────────────────────────────────────────
  let isDrawing  = false;
  let lastX      = 0;
  let lastY      = 0;

  // ── Canvas setup ─────────────────────────────────────────────────────────
  function setupCanvas() {
    ctx.fillStyle = "#ffffff";          // white background
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#000000";        // black ink
    ctx.lineWidth   = 15;
    ctx.lineCap     = "round";
    ctx.lineJoin    = "round";
  }

  setupCanvas();

  // ── Helper: canvas coordinates from mouse/touch event ───────────────────
  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    // Support both mouse and touch events
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  }

  // ── Drawing handlers ─────────────────────────────────────────────────────
  function startDraw(e) {
    e.preventDefault();
    isDrawing = true;
    const { x, y } = getPos(e);
    lastX = x;
    lastY = y;
    // Draw a dot for single clicks/taps
    ctx.beginPath();
    ctx.arc(x, y, ctx.lineWidth / 2, 0, Math.PI * 2);
    ctx.fillStyle = "#000000";
    ctx.fill();
  }

  function draw(e) {
    if (!isDrawing) return;
    e.preventDefault();
    const { x, y } = getPos(e);

    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(x, y);
    ctx.stroke();

    lastX = x;
    lastY = y;
  }

  function stopDraw(e) {
    if (isDrawing) {
      e.preventDefault();
      isDrawing = false;
    }
  }

  // ── Mouse events ─────────────────────────────────────────────────────────
  canvas.addEventListener("mousedown",  startDraw);
  canvas.addEventListener("mousemove",  draw);
  canvas.addEventListener("mouseup",    stopDraw);
  canvas.addEventListener("mouseleave", stopDraw);

  // ── Touch events (mobile support) ────────────────────────────────────────
  canvas.addEventListener("touchstart", startDraw, { passive: false });
  canvas.addEventListener("touchmove",  draw,      { passive: false });
  canvas.addEventListener("touchend",   stopDraw,  { passive: false });

  // ── Clear canvas ─────────────────────────────────────────────────────────
  function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setupCanvas();
    showResult(null);    // reset result area
  }

  // ── Send image to backend & display result ────────────────────────────────
  async function sendPrediction() {
    const imageData = canvas.toDataURL("image/png");

    // Show loading state
    setLoading(true);
    showResult(null);

    try {
      const response = await fetch("/predict", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ image: imageData }),
      });

      const data = await response.json();

      if (data.error) {
        showError(data.error);
      } else {
        showResult(data);
      }
    } catch (err) {
      showError("Network error – is the Flask server running?");
    } finally {
      setLoading(false);
    }
  }

  // ── UI helpers ────────────────────────────────────────────────────────────

  /** Toggle the loading spinner visibility. */
  function setLoading(show) {
    loader.style.display = show ? "flex" : "none";
    predictBtn.disabled  = show;
  }

  /** Render prediction results into the result panel. */
  function showResult(data) {
    if (!data) {
      resultBox.innerHTML = `
        <p class="placeholder-text">Draw a digit and click <strong>Predict</strong></p>`;
      return;
    }

    const digits = data.digits || [];
    const conf   = data.average_confidence ?? (digits[0]?.confidence ?? 0);

    // Build per-digit chips
    const chips = digits.map((d) =>
      `<span class="digit-chip">
         <span class="chip-digit">${d.digit}</span>
         <span class="chip-conf">${d.confidence.toFixed(1)}%</span>
       </span>`
    ).join("");

    resultBox.innerHTML = `
      <div class="result-main">${data.prediction}</div>
      <div class="digit-chips">${chips}</div>
      <div class="conf-bar-wrap">
        <div class="conf-bar" style="width:${conf}%"></div>
      </div>
      <div class="conf-label">Avg confidence: <strong>${conf.toFixed(1)}%</strong></div>
    `;
  }

  /** Display an error message in the result panel. */
  function showError(msg) {
    resultBox.innerHTML = `<p class="error-text">⚠ ${msg}</p>`;
  }

  // ── Button listeners ──────────────────────────────────────────────────────
  predictBtn.addEventListener("click", sendPrediction);
  clearBtn.addEventListener("click",   clearCanvas);

  // ── Keyboard shortcut: Enter = Predict, Escape = Clear ──────────────────
  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter")  sendPrediction();
    if (e.key === "Escape") clearCanvas();
  });

})();
